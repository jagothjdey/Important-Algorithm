import UIKit

struct User{
    var userName: String
    
    init() {
        userName = "Anonymous"
        print("Creating a new user")
    }
}

var user = User()
user.userName = "Akkas"
print(user.userName)
